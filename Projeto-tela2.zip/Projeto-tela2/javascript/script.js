const form = document.querySelector("#form");
const nomeInput = document.querySelector("#nome");
const cpfInput = document.querySelector("#CPF");
const generoInput = document.querySelector("#genero");
const datanascimentoInput = document.querySelector("#datanascimento");
const nomematernoInput = document.querySelector("#nomematerno");
const celularInput = document.querySelector("#celular");
const telfixoInput = document.querySelector("#telfixo");
const cepInput = document.querySelector("#cep");
const ruaInput = document.querySelector("#rua");
const numeroInput = document.querySelector("#numero");
const bairroInput = document.querySelector("bairro");
const cidadeInput = document.querySelector("cidade");
const estadoInput = document.querySelector("estado");
const loginInput = document.querySelector("#login");
const senhaInput = document.querySelector("#senha");
const confirmarsenhaInput = document.querySelector("#confirmarsenha");
const messagetextarea = document.querySelector("#message");

form.addEventListener("submit",(event) => {
    event.preventDefault();

    //validações
    if(nomeInput.value === "") {
        alert("Por favor, preencha seu nome");
        return;
    }
    //validação complexa###
    if(cpfInput.value === "") {
        alert("Por favor, preencha seu CPF");
        return;
    }
    if(generoInput.value === "0") {
        alert("Por favor, selecione seu gênero");
        return;
    }
    //validação complexa###
    if(datanascimentoInput.value === "") {
        alert("Por favor, preencha sua data de nascimento");
        return;
    }
    if(nomematernoInput.value === "") {
        alert("Por favor, preencha seu nome materno");
        return;
    }
    if(celularInput.value === "") {
        alert("Por favor, preencha seu celular");
        return;
    }
    if(telfixoInput.value === "") {
        alert("Por favor, preencha seu telefone fixo");
        return;
    }
    if(cepInput.value === "") {
        alert("Por favor, preencha seu CEP");
        return;
    }
    if(ruaInput.value === "") {
        alert("Por favor, preencha sua Rua");
        return;
    }if(numeroInput.value === "") {
        alert("Por favor, preencha seu número residencial");
        return;
    }
    if(bairroInput.value === "") {
        alert("Por favor, preencha seu bairro");
        return;
    }
    if(cidadeInput.value === "") {
        alert("Por favor, preencha sua cidade");
        return;
    }
    if(estadoInput.value === "") {
        alert("Por favor, preencha seu estado");
        return;
    }
    if(loginInput.value === "") {
        alert("Por favor, preencha seu Login");
        return;
    }
    if(validaSenha(senhaInput.value ,8)){
        alert("A senha deve ter no mínimo 8 digitos")
    }
    if(confirmarsenhaInput.value === "") {
        alert("Por favor, confirme sua senha");
        return;
    }



    //envio de formulário validado
    form.submit();

})

//Função que valida a senha
function validaSenha(senha, minDigits) {
    if(senha.length >= minDigits) {
        //senha válida
        return true
    }
    //senha inválida
    return false
}

function validaConfSenha(confirmasenha) {
    if(senha===confirmasenha) {
        return true
    }
    return false
}