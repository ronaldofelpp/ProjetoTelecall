document.getElementById('btnSwitch').addEventListener('click',()=>{
    if (document.documentElement.getAttribute('data-bs-theme') == 'dark'){
        document.documentElement.setAttribute('data-bs-theme','light');

        (document.getElementById('logotelecall').getAttribute('src') == 'imagens/imagens-tela3/logo-telecall.png')
        document.getElementById('logotelecall').setAttribute('src','imagens/imagens-tela3/')
    }
    
    else {
        document.documentElement.setAttribute('data-bs-theme','dark')
        document.getElementById('logotelecall').setAttribute('src', 'imagens/imagens-tela3/logo-telecall.png')

    }
})
