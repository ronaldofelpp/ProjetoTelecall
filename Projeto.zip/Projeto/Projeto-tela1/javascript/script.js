jQuery.validator.setDefaults({
    debug: true,
    success: "valid"
  });
$("#form").validate({
    normalizer: function( value ) {
        return $.trim( value );
    },
    rules:{
        login:{
            required: true,
        },
        senha:{
            required: true,
        },
    },
    messages: {
        login:{
            required: "*Informe seu Login",
        },

        senha: {
            required: "*Informe sua senha",
        },
    }
});