<?php
    /*Variáveis criadas para receber e armazenar os valores enviados pelo formulário
    de cadastro via método POST*/
    $nome = $_POST['nome'];
    $cpf = $_POST['CPF'];
    //código exemplo para filtrar o valor da variável $cpf, tirando caracteres como "." e "-".
    $cpfFiltrado = str_replace(array('.','-'), '', $cpf);

    $genero = $_POST['genero'];
    $data_nasc = $_POST['datanascimento'];
    $nomemat = $_POST['nomematerno'];
    $cel = $_POST['celular'];

    $celFiltrado = str_replace(array('(',')','-',' '), '', $cel);

    $tel = $_POST['telfixo'];

    $telFiltrado = str_replace(array('(',')','-',' '), '', $tel);

    $cep = $_POST['cep'];

    $cepFiltrado = str_replace(array('-',' '), '', $cep);

    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $cod_uf = $_POST['estado'];
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    include 'conexao.php';
    
    // Váriavel com consulta para verificar se o login ou o email já existem no banco de dados
    $sql_check = "SELECT CPF FROM usuario WHERE CPF = '$cpfFiltrado'";
    $result = mysqli_query($conn, $sql_check);
    /*Condição para verificar se na consulta o programa retornou mais de 0 linhas, se retornar,
    existem dados repetidos*/
    if (mysqli_num_rows($result) > 0){
        echo "CPF já cadastrado em outra conta <a href=tela2.html>Tentar novamente</a>";
    }else{
        $sql_check = "SELECT LOGIN  FROM usuario WHERE LOGIN = '$login' ";
        $result = mysqli_query($conn, $sql_check);
        /*Condição para verificar se na consulta o programa retornou mais de 0 linhas, se retornar,
        existem dados repetidos*/
        if (mysqli_num_rows($result) > 0){
            echo "Login já cadastrado em outra conta <a href=tela2.html>Tentar novamente</a>";
        } else {
            $sql_endereco = "INSERT INTO ENDERECO (CEP, Rua, Numero, Bairro, Cidade, Cod_uf) VALUES ('$cepFiltrado','$rua', '$numero', '$bairro', '$cidade', '$cod_uf')";
            if ($conn->query($sql_endereco) === TRUE) {
                // Recupera o ID do endereço recém-inserido
                $idEndereco = $conn->insert_id;
        
                // Insere dados na tabela "contato"
                $sql_contato = "INSERT INTO CONTATO (cel1, cel2) VALUES ('$celFiltrado', '$telFiltrado')";
                if ($conn->query($sql_contato) === TRUE) {
                    // Recupera o ID de contato recém-inserido
                    $idContato = $conn->insert_id;
        
                    // Insere dados na tabela "usuário" com os IDs de endereço e contato
                    $sql_usuario = "INSERT INTO USUARIO (Nome, CPF, Genero, DataNasc, NomeMat, Login, Senha, Status, DataInclu, DataUltAlt, idENDERECO, idCONTATO, idTIPO) VALUES ('$nome', '$cpfFiltrado', '$genero', '$data_nasc', '$nomemat', '$login', '$senha', 'Ativo', current_timestamp(),current_timestamp(), $idEndereco, $idContato , 1)";
                    if ($conn->query($sql_usuario) === TRUE) {
                        echo "Cadastro realizado com sucesso, <a href=tela1.html>iniciar sessão agora.</a>";
                    } else {
                        echo "Erro ao registrar usuário: " . $conn->error;
                    }
                } else {
                    echo "Erro registrar o contato do usuário: " . $conn->error;
                }
            } else {
                echo "Erro ao registrar o endereço do usuário: " . $conn->error;
            }
        
            // Fecha a conexão com o banco de dados

        }; 
        //Fecha a conexão com o banco de dados quando a operação é concluída
        $conn->close();
    }
    



?>

