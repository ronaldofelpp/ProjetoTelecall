<?php
    //Variáveis criadas armazenar as variáveis enviadas pelo formulário
    $nome = $_POST['nome'];
    $cpf = $_POST['CPF'];
    //código para filtrar o valor da variável $cpf, tirando caracteres como "." e "-".
    $cpfFiltrado = str_replace(array('.', '-'), '', $cpf);

    $genero = $_POST['genero'];
    $data_nasc = $_POST['datanascimento'];
    $nomemat = $_POST['nomematerno'];
    $cel = $_POST['celular'];

    $celFiltrado = str_replace(array('(',')','-',' '), '', $cel);

    $tel = $_POST['telfixo'];

    $telFiltrado = str_replace(array('(',')','-',' '), '', $tel);

    $cep = $_POST['cep'];

    $cepFiltrado = str_replace(array('-',' '), '', $cep);

    $rua = $_POST['rua'];
    $numero = $_POST['numero'];
    $bairro = $_POST['bairro'];
    $cidade = $_POST['cidade'];
    $cod_uf = $_POST['estado'];
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    include 'conexao.php';
    $conn -> begin_transaction();

    try{    
        // verifica se o cpf já existe
        $sql_check = "SELECT CPF FROM usuario WHERE CPF = '$cpfFiltrado'";
        $result = mysqli_query($conn, $sql_check);

       //checa se retornou mais de 0 linhas
        if (mysqli_num_rows($result) > 0){
            echo "CPF já cadastrado em outra conta <a href=tela2.html>Tentar novamente</a>";
        }else{
            $sql_check = "SELECT LOGIN  FROM usuario WHERE LOGIN = '$login' "; //verifica se o login já existe
            $result = mysqli_query($conn, $sql_check);
            
            if (mysqli_num_rows($result) > 0){
                echo "Login já cadastrado em outra conta <a href=tela2.html>Tentar novamente</a>";
            } else {
                //insere dados na tabela endereço
                $sql_endereco = "INSERT INTO ENDERECO (CEP, Rua, Numero, Bairro, Cidade, Cod_uf) VALUES (?, ?, ?, ?, ?, ?)";
                $statement = $conn->prepare($sql_endereco);
                $statement->bind_param("ssssss", $cepFiltrado, $rua, $numero, $bairro, $cidade, $cod_uf);

                if ($statement->execute()) {
                    
                    $idEndereco = $statement->insert_id; // Recupera o ID do endereço recém-inserido
            
                    // Insere dados na tabela contato
                    $sql_contato = "INSERT INTO CONTATO (cel1, cel2) VALUES (?, ?)";
                    $statement = $conn->prepare($sql_contato);
                    $statement->bind_param("ss", $celFiltrado, $telFiltrado);
                    if ($statement->execute()) {
                        
                        $idContato = $statement->insert_id; // Recupera o ID de contato recém-inserido
                        
                        //insere dados na tabela usuario
                        $sql_usuario = "INSERT INTO USUARIO (Nome, CPF, Genero, DataNasc, NomeMat, Login, Senha, Status, DataInclu, DataUltAlt, idENDERECO, idCONTATO, idTIPO) VALUES (?, ?, ?, ?, ?, ?, ?, 'Ativo', current_timestamp(),current_timestamp(),? ,? , 1)";
                        $statement = $conn->prepare($sql_usuario);
                        $statement->bind_param("sssssssii", $nome, $cpfFiltrado, $genero, $data_nasc, $nomemat, $login, $senha, $idEndereco, $idContato);
                        if ($statement->execute()) {
                            $conn->commit(); //confirma a transação
                            echo "Cadastro realizado com sucesso, <a href=tela1.html>iniciar sessão agora.</a>";
                            
                        } else {
                            throw new Exception("insert na tabela usuário");
                        }
                    } else {
                        throw new Exception("insert na tabela contato");
                    }
                } else {
                    throw new Exception("insert na tabela endereco");
                }
            };
        }
    } catch (Exception $erro) {
        $conn->rollback();
        echo "Erro na transação: ". $erro->getMessage();
    }        
            //Fecha a conexão com o banco de dados quando a operação é concluída
            $conn->close();
    
    



?>

