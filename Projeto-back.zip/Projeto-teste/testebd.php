<?php

include 'conexao.php';
/*Variável com uma consulta SQL criada para verificar se o login e senha correspondem
a um registro no banco de dados*/
$sql = "UPDATE USUARIO SET NOME = '$nome', GENERO = '$genero', DATAULTALT = current_timestamp() WHERE CPF = '$cpf'";

if ($conn->query($sql) === TRUE ) {
    $sql = "UPDATE ENDERECO SET CEP = '$cepFiltrado', RUA = '$rua', NUMERO = '$numero', BAIRRO = '$bairro', CIDADE = '$cidade', COD_UF = '$cod_uf' WHERE IDENDERECO = '$idendereco'";

    if ($conn->query($sql) === TRUE ) {
        $sql = "UPDATE CONTATO SET CEL1  = '$cel1Filtrado', CEL2 = '$cel2Filtrado' WHERE IDCONTATO = '$idcontato'";

        if ($conn->query($sql) === TRUE ) {
            echo "Dados alterados com sucesso, <a href=encerrasessao.php>entre novamente na sua conta</a>";
        }

    }
}
 //Fecha a conexão com o banco de dados quando a operação é concluída
$conn->close();

?>