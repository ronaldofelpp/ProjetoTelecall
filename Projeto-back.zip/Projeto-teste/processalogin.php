<?php
     /*função para iniciar uma sessão php, permitindo o uso de variáveis de sessão,
    que funcionam em diversas páginas diferentes*/
    session_start();

    /*Variáveis criadas para receber e armazenar os valores enviados pelo formulário
    de login via método POST*/
    $login = $_POST['login'];
    $senha = $_POST['senha'];

    include 'conexao.php';

    /*Variável com uma consulta SQL criada para verificar se o login e senha correspondem
    a um registro no banco de dados*/
    $sql = "SELECT  NOME, CPF, NOMEMAT, idTIPO, STATUS FROM usuario WHERE LOGIN = '$login' AND SENHA = '$senha'";
    /*Executa a consulta SQL e armazena o resultado na variável $result*/
    $result = $conn->query($sql);
     //Fecha a conexão com o banco de dados quando a operação é concluída
    $conn->close();

    
    /*O IF verifica se a consulta retornou pelo menos uma linha, se retornar
    obviamente seu login foi bem-sucedido*/
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $status = $row['STATUS'];
        if($status == 'Ativo'){
            include 'conexao.php';

            /*Variável com uma consulta SQL criada para verificar se o login e senha correspondem
            a um registro no banco de dados*/
            $sql = "SELECT  NOME, CPF, NOMEMAT, idTIPO, STATUS FROM usuario WHERE LOGIN = '$login' AND SENHA = '$senha'";
            /*Executa a consulta SQL e armazena o resultado na variável $result*/
            $result = $conn->query($sql);
             //Fecha a conexão com o banco de dados quando a operação é concluída
            $conn->close();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc(); //<- Obtém os dados do usuário da linha retornada pela consulta
                $_SESSION["CPF"] = $row["CPF"];
                $_SESSION["nome"] = $row["NOME"]; //<- Armazenam as informações da linha numa váriavel de sessão
                $_SESSION["tipo"] = $row["idTIPO"];
                $_SESSION["nomematerno"] = $row["NOMEMAT"];
                
                if ($_SESSION["tipo"]=='1'){
                    header('location: autenticacao.php');

                } elseif ($_SESSION["tipo"]=='2') {
                    header('location: telaescolha.php');
                } else {
                    echo 'Tipo de usuário desconhecido,<a href="encerrasessao.php">Tente novamente</a>';
                };
            }
        } else {
            echo 'Usuário está inativo, contate o número 0000-0000 para reverter isso. <a href="encerrasessao.php">Voltar</a>';
        };
    }else {
    echo 'Login ou senha incorretos. <a href="encerrasessao.php">Tente novamente</a>';
    };

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/visualizarusu.css">
</head>
<body>
    
</body>
</html>