<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema</title>
</head>
<body>
    <?php
        session_start();

        if(!isset($_SESSION['CPF'])) {
            header('location: tela1.html');
            exit();
        }
        $_SESSION["CPF"];
        $_SESSION["nome"];



        echo 'Bem-vindo(a) usuário master, ',$_SESSION['nome'].' ';

        echo '<a href="encerrasessao.php">Sair</a>';

    ?>


    
</body>
</html>